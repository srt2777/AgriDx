import { loadKnowledgeSnapshot } from './snapshot';
/** Compatibility entry; initialization is shared with retrieval and statistics. */
export function loadKnowledgeCatalog() {
    return loadKnowledgeSnapshot().getCatalog();
}
export function getKnowledgeCatalog(filters = {}) {
    return loadKnowledgeSnapshot().getCatalog(filters);
}
