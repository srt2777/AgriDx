import { getLiterature } from './knowledge/literature';
import { getMemoryStore } from './memory/store';
import fs from 'node:fs';
import path from 'node:path';
import { initializeEnvironment } from './config/environment';
import { createDiagnosticService } from './diagnosis/service';
import { getKnowledgeCatalog, loadKnowledgeCatalog } from './knowledge/catalog';
import { loadKnowledgeBase, stats } from './knowledge/retriever';
import { getLlmRouter } from './llm/router';
import { telemetryFromEnvironment } from './telemetry/runtime';
/** Explicit startup composition; importing the app factory performs no initialization. */
export function createServerRuntime() {
    initializeEnvironment();
    loadKnowledgeBase();
    loadKnowledgeCatalog();
    const llm = getLlmRouter();
    const rootDirectory = process.cwd();
    const version = JSON.parse(fs.readFileSync(path.resolve(rootDirectory, 'package.json'), 'utf8')).version;
    return {
        rootDirectory, version, getMemoryStore,
        telemetry: telemetryFromEnvironment(rootDirectory),
        diagnose: createDiagnosticService(llm, { literatureSearch: getLiterature }),
        getKnowledgeStats: stats,
        getLlmStatus: () => llm.getStatus(),
        getCatalog: getKnowledgeCatalog,
    };
}
