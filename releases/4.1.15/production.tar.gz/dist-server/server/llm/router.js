/**
 * 按配置选择 LLM，并在主选失败时尝试另一家已配置的 provider。
 * auto 保留现有路由：配置 Gemini 时优先 Gemini，否则 DeepSeek。
 * 显式 deepseek/gemini 只设置优先顺序；缺少主选 Key 时仍使用另一家。
 * 状态和日志只包含配置概要与错误类别，不暴露凭据或上游响应体。
 */
import { detectProxy } from './http';
import { createGeminiProvider } from './gemini';
import { createDeepSeekProvider } from './deepseek';
import { ProviderError, } from './types';
function getPreference() {
    const value = process.env.LLM_PROVIDER?.trim().toLowerCase() || 'auto';
    return value === 'auto' || value === 'gemini' || value === 'deepseek' ? value : null;
}
function asProviderError(provider, error) {
    return error instanceof ProviderError
        ? error
        : new ProviderError(provider, 'unknown', 'unexpected provider error');
}
export class LlmRouter {
    gemini;
    deepseek;
    constructor() {
        this.gemini = createGeminiProvider();
        this.deepseek = createDeepSeekProvider();
    }
    /** 不发起联网请求；健康接口可安全暴露此概要。 */
    getStatus() {
        const preference = getPreference();
        const providers = [this.gemini, this.deepseek].map((provider) => ({
            provider: provider.name,
            model: provider.model,
            configured: provider.isConfigured(),
        }));
        const configured = preference !== null && providers.some((provider) => provider.configured);
        return {
            preference,
            configValid: preference !== null,
            ...(preference === null ? { configurationError: 'invalid_provider' } : {}),
            configured,
            primary: configured ? this.pickPrimary(preference).primary.name : null,
            proxyConfigured: detectProxy().present,
            providers,
        };
    }
    printConfig() {
        const status = this.getStatus();
        console.log(`[llm] preference=${status.preference ?? 'invalid'} ` +
            `gemini=${this.gemini.isConfigured() ? 'configured' : 'missing'} ` +
            `deepseek=${this.deepseek.isConfigured() ? 'configured' : 'missing'} ` +
            `proxy=${status.proxyConfigured ? 'detected' : 'none'} (connection unverified)`);
    }
    hasAnyConfigured() {
        return this.getStatus().configured;
    }
    /**
     * Shadow tool use only; never affects ordinary chat routing. Prefers the ordinary primary when it
     * supports tool calls, otherwise any other configured tool-capable provider (Gemini has none).
     */
    toolProvider() {
        const preference = getPreference();
        if (preference === null)
            return null;
        const { primary, secondary } = this.pickPrimary(preference);
        return [primary, secondary].find(provider => provider.isConfigured() && provider.chatWithTools) ?? null;
    }
    pickPrimary(preference) {
        // auto 保持旧行为：两家都有 Key 时仍优先 Gemini。
        let first = preference === 'deepseek' ? this.deepseek
            : preference === 'gemini' ? this.gemini
                : this.gemini.isConfigured() || detectProxy().present ? this.gemini : this.deepseek;
        let second = first === this.gemini ? this.deepseek : this.gemini;
        if (!first.isConfigured() && second.isConfigured())
            [first, second] = [second, first];
        return { primary: first, secondary: second };
    }
    async chatStream(messages, onDelta, options) {
        const preference = getPreference();
        if (preference === null) {
            throw new ProviderError('deepseek', 'configuration', 'invalid LLM_PROVIDER');
        }
        const { primary, secondary } = this.pickPrimary(preference);
        if (!primary.isConfigured()) {
            throw new ProviderError(primary.name, 'configuration', 'no LLM API key configured');
        }
        let emitted = false;
        const guard = (text) => { emitted = true; onDelta(text); };
        const run = async (provider) => {
            if (provider.chatStream)
                return provider.chatStream(messages, guard, options);
            const result = await provider.chat(messages);
            guard(result.content);
            return result;
        };
        let primaryError;
        try {
            const result = await run(primary);
            return { result, primary: primary.name, fellBack: false, attempts: 1 };
        }
        catch (error) {
            primaryError = asProviderError(primary.name, error);
            console.warn(`[llm] primary ${primary.name} failed (${primaryError.kind})`);
        }
        // A stream that already emitted text cannot be replaced by the other
        // provider: the client already saw the first provider's words, so a
        // second provider's answer would splice onto a partial reply.
        if (emitted) {
            primaryError.attempts = 1;
            throw primaryError;
        }
        if (!secondary.isConfigured()) {
            primaryError.attempts = 1;
            throw primaryError;
        }
        try {
            const result = await run(secondary);
            return { result, primary: primary.name, fellBack: true, fallbackReason: primaryError.kind, attempts: 2 };
        }
        catch (error) {
            const secondaryError = asProviderError(secondary.name, error);
            secondaryError.attempts = 2;
            console.warn(`[llm] secondary ${secondary.name} failed (${secondaryError.kind})`);
            throw secondaryError;
        }
    }
    async chat(messages) {
        const preference = getPreference();
        if (preference === null) {
            throw new ProviderError('deepseek', 'configuration', 'invalid LLM_PROVIDER');
        }
        const { primary, secondary } = this.pickPrimary(preference);
        if (!primary.isConfigured()) {
            throw new ProviderError(primary.name, 'configuration', 'no LLM API key configured');
        }
        let primaryError;
        try {
            const result = await primary.chat(messages);
            return { result, primary: primary.name, fellBack: false, attempts: 1 };
        }
        catch (error) {
            primaryError = asProviderError(primary.name, error);
            console.warn(`[llm] primary ${primary.name} failed (${primaryError.kind})`);
        }
        if (!secondary.isConfigured()) {
            primaryError.attempts = 1;
            throw primaryError;
        }
        try {
            const result = await secondary.chat(messages);
            return { result, primary: primary.name, fellBack: true, fallbackReason: primaryError.kind, attempts: 2 };
        }
        catch (error) {
            const secondaryError = asProviderError(secondary.name, error);
            secondaryError.attempts = 2;
            console.warn(`[llm] secondary ${secondary.name} failed (${secondaryError.kind})`);
            throw secondaryError;
        }
    }
}
let singleton = null;
export function getLlmRouter() {
    if (!singleton) {
        singleton = new LlmRouter();
        singleton.printConfig();
    }
    return singleton;
}
