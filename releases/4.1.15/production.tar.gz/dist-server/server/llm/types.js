/**
 * LLM Provider 统一接口
 *
 * 所有 provider 实现该接口，由 router 统一调度。
 * 统一返回结构，路由层不再关心是 Gemini 还是 DeepSeek。
 */
/** 调用失败时抛出，router 据此决定是否 fallback */
export class ProviderError extends Error {
    provider;
    kind;
    detail;
    /** Number of generation attempts made; no extra scoring/classification request. */
    attempts = 0;
    constructor(provider, kind, detail) {
        super(`[${provider}] ${kind}`);
        this.provider = provider;
        this.kind = kind;
        this.detail = detail;
        this.name = 'ProviderError';
    }
}
