/**
 * OpenAI 兼容 chat/completions 通用请求实现。
 * Gemini (v1beta/openai) 与 DeepSeek 都遵循此格式，差别只在 URL/Model/Key。
 */
import { fetchWithTimeout } from './http';
import { parseDsmlToolCalls, stripDsmlMarkup } from '../../agent/dsml';
import { ProviderError, } from './types';
export function createOpenAICompatibleProvider(opts) {
    const { name, model, apiUrl, apiKeyEnv, timeoutMs = 25_000, selfIntro } = opts;
    function getKey() {
        return process.env[apiKeyEnv]?.trim() || undefined;
    }
    return {
        name,
        model,
        isConfigured() {
            const k = getKey();
            return Boolean(k && k.trim().length > 0);
        },
        ...(name === 'gemini' ? {} : { async chatWithTools(messages, options) {
                const apiKey = getKey();
                if (!apiKey)
                    throw new ProviderError(name, 'configuration', `missing ${apiKeyEnv}`);
                const outgoing = selfIntro ? (() => { const copy = [...messages]; if (copy[0]?.role === 'system')
                    copy[0] = { ...copy[0], content: copy[0].content + '\n\n' + selfIntro };
                else
                    copy.unshift({ role: 'system', content: selfIntro }); return copy; })() : messages;
                let data;
                try {
                    data = await fetchWithTimeout(apiUrl, { method: 'POST', signal: options.signal, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` }, body: JSON.stringify({ model, messages: outgoing, temperature: 0.3, stream: false, ...(options.tools.length ? { tools: options.tools.map(tool => ({ type: 'function', function: { name: tool.name, description: tool.description, parameters: tool.input_schema } })), tool_choice: options.toolChoice ?? 'auto' } : {}) }) }, timeoutMs, async (response) => {
                        if (!response.ok) {
                            const kind = response.status === 401 || response.status === 403 ? 'auth' : response.status === 429 ? 'rate_limit' : response.status === 400 || response.status === 422 ? 'bad_request' : response.status >= 500 ? 'server_error' : 'unknown';
                            throw new ProviderError(name, kind, `HTTP ${response.status}`);
                        }
                        try {
                            return await response.json();
                        }
                        catch (error) {
                            if (error instanceof Error && error.name === 'AbortError')
                                throw error;
                            throw new ProviderError(name, 'invalid_response', 'response is not valid JSON');
                        }
                    });
                }
                catch (error) {
                    if (error instanceof ProviderError)
                        throw error;
                    const kind = error instanceof Error && error.message === 'cancelled' ? 'cancelled' : error instanceof Error && error.message === 'timeout' ? 'timeout' : 'network';
                    throw new ProviderError(name, kind, 'request failed');
                }
                const record = data && typeof data === 'object' ? data : {};
                const choice = Array.isArray(record.choices) ? record.choices[0] : undefined;
                const message = choice && typeof choice === 'object' ? choice.message : undefined;
                const rawCalls = message?.tool_calls;
                if (rawCalls !== undefined && (!Array.isArray(rawCalls) || rawCalls.length > 4))
                    throw new ProviderError(name, 'invalid_response', 'invalid tool calls');
                const ids = new Set();
                let toolCalls = (rawCalls ?? []).map((call) => {
                    if (!call || typeof call !== 'object')
                        throw new ProviderError(name, 'invalid_response', 'invalid tool call');
                    const item = call;
                    if (typeof item.id !== 'string' || !item.id || item.id.length > 200 || ids.has(item.id) || item.type !== 'function' || typeof item.function?.name !== 'string' || !/^[a-zA-Z0-9_-]{1,64}$/.test(item.function.name) || typeof item.function.arguments !== 'string' || item.function.arguments.length > 100_000)
                        throw new ProviderError(name, 'invalid_response', 'invalid tool call');
                    ids.add(item.id);
                    let input;
                    try {
                        input = JSON.parse(item.function.arguments);
                    }
                    catch {
                        throw new ProviderError(name, 'invalid_response', 'invalid tool arguments');
                    }
                    if (!input || typeof input !== 'object' || Array.isArray(input))
                        throw new ProviderError(name, 'invalid_response', 'invalid tool arguments');
                    return { id: item.id, name: item.function.name, input: input };
                });
                const finish = choice?.finish_reason;
                let content = typeof message?.content === 'string' ? message.content.trim() : '';
                // DeepSeek V4 Flash models natively emit tool calls as DSML text
                // (see agent/dsml.ts). When the serving stack does not convert that
                // text into structured tool_calls, translate a well-formed DSML block
                // here instead of letting it leak into a final answer (finish "stop")
                // or failing the turn as an invalid response (finish "tool_calls").
                // A malformed DSML block is stripped, never half-executed: the
                // remaining text is then validated by the usual rules below.
                let dsmlConverted = false;
                if (toolCalls.length === 0 && (finish === 'stop' || finish === 'tool_calls')) {
                    const dsml = parseDsmlToolCalls(content);
                    if (dsml && dsml.length <= 4) {
                        toolCalls = dsml;
                        content = stripDsmlMarkup(content);
                        dsmlConverted = true;
                    }
                    else
                        content = stripDsmlMarkup(content);
                }
                else if (toolCalls.length > 0) {
                    content = stripDsmlMarkup(content);
                }
                if (!['tool_calls', 'stop', 'length'].includes(finish) || ((finish === 'tool_calls') !== Boolean(toolCalls.length) && !dsmlConverted))
                    throw new ProviderError(name, 'invalid_response', 'invalid finish reason');
                if (!content && !toolCalls.length)
                    throw new ProviderError(name, 'invalid_response', 'missing assistant content');
                return { content, toolCalls, stopReason: dsmlConverted ? 'tool_calls' : finish };
            } }),
        async chat(messages) {
            const apiKey = getKey();
            if (!apiKey) {
                throw new ProviderError(name, 'configuration', `missing ${apiKeyEnv}`);
            }
            // 追加模型自述（让模型被问到时如实回答自己是谁）
            const outgoing = selfIntro
                ? (() => {
                    const withIntro = [...messages];
                    if (withIntro[0]?.role === 'system') {
                        withIntro[0] = { ...withIntro[0], content: withIntro[0].content + '\n\n' + selfIntro };
                    }
                    else {
                        withIntro.unshift({ role: 'system', content: selfIntro });
                    }
                    return withIntro;
                })()
                : messages;
            let data;
            try {
                data = await fetchWithTimeout(apiUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${apiKey}`,
                    },
                    body: JSON.stringify({
                        model,
                        messages: outgoing,
                        temperature: 0.3,
                        stream: false,
                    }),
                }, timeoutMs, async (response) => {
                    if (!response.ok) {
                        // 上游错误体可能回显凭据或提示词，仅保留状态码。
                        const detail = `HTTP ${response.status}`;
                        if (response.status === 401 || response.status === 403) {
                            throw new ProviderError(name, 'auth', detail);
                        }
                        if (response.status === 400 || response.status === 422) {
                            throw new ProviderError(name, 'bad_request', detail);
                        }
                        if (response.status === 429)
                            throw new ProviderError(name, 'rate_limit', detail);
                        if (response.status >= 500)
                            throw new ProviderError(name, 'server_error', detail);
                        throw new ProviderError(name, 'unknown', detail);
                    }
                    try {
                        return await response.json();
                    }
                    catch (error) {
                        if (error instanceof Error && error.name === 'AbortError')
                            throw error;
                        throw new ProviderError(name, 'invalid_response', 'response is not valid JSON');
                    }
                });
            }
            catch (err) {
                if (err instanceof ProviderError)
                    throw err;
                // 网络层错误（含超时）
                const kind = err instanceof Error && err.message === 'timeout' ? 'timeout' : 'network';
                // 原始异常可能包含 URL、代理凭据或请求信息，不能向日志/调用方传播。
                throw new ProviderError(name, kind, kind === 'timeout' ? 'request timed out' : 'request failed');
            }
            const record = data && typeof data === 'object' ? data : {};
            const choice = Array.isArray(record.choices) ? record.choices[0] : undefined;
            const message = choice && typeof choice === 'object' ? choice.message : undefined;
            const content = typeof message?.content === 'string' ? message.content.trim() : '';
            if (!content) {
                throw new ProviderError(name, 'invalid_response', 'missing assistant content');
            }
            const usage = {};
            const rawUsage = record.usage;
            if (rawUsage && typeof rawUsage === 'object') {
                for (const field of ['prompt_tokens', 'completion_tokens', 'total_tokens']) {
                    const value = rawUsage[field];
                    if (typeof value === 'number' && Number.isFinite(value) && value >= 0)
                        usage[field] = value;
                }
            }
            return {
                content,
                provider: name,
                model: typeof record.model === 'string' && record.model.trim() ? record.model.trim() : model,
                usage: Object.keys(usage).length ? usage : undefined,
            };
        },
        async chatStream(messages, onDelta, options = {}) {
            const apiKey = getKey();
            if (!apiKey) {
                throw new ProviderError(name, 'configuration', `missing ${apiKeyEnv}`);
            }
            // Same self-intro handling as chat(): the model must answer for
            // itself with the configured name when asked.
            const outgoing = selfIntro
                ? (() => {
                    const withIntro = [...messages];
                    if (withIntro[0]?.role === 'system') {
                        withIntro[0] = { ...withIntro[0], content: withIntro[0].content + '\n\n' + selfIntro };
                    }
                    else {
                        withIntro.unshift({ role: 'system', content: selfIntro });
                    }
                    return withIntro;
                })()
                : messages;
            let content = '';
            let upstreamModel;
            let sawDone = false;
            const usage = {};
            const readUsage = (rawUsage) => {
                if (!rawUsage || typeof rawUsage !== 'object')
                    return;
                for (const field of ['prompt_tokens', 'completion_tokens', 'total_tokens']) {
                    const value = rawUsage[field];
                    if (typeof value === 'number' && Number.isFinite(value) && value >= 0)
                        usage[field] = value;
                }
            };
            const handleLine = (line) => {
                if (!line.startsWith('data:'))
                    return;
                const data = line.slice(5).trim();
                if (!data)
                    return;
                if (data === '[DONE]') {
                    sawDone = true;
                    return;
                }
                let parsed;
                try {
                    parsed = JSON.parse(data);
                }
                catch {
                    return;
                }
                if (!parsed || typeof parsed !== 'object')
                    return;
                const record = parsed;
                const choice = Array.isArray(record.choices) ? record.choices[0] : undefined;
                const delta = choice && typeof choice === 'object' ? choice.delta : undefined;
                const text = delta && typeof delta === 'object' && typeof delta.content === 'string'
                    ? delta.content : '';
                if (text) {
                    content += text;
                    onDelta(text);
                }
                if (typeof record.model === 'string' && record.model.trim())
                    upstreamModel = record.model.trim();
                readUsage(record.usage);
            };
            try {
                await fetchWithTimeout(apiUrl, {
                    method: 'POST',
                    signal: options.signal,
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${apiKey}`,
                    },
                    body: JSON.stringify({
                        model,
                        messages: outgoing,
                        temperature: 0.3,
                        stream: true,
                    }),
                }, timeoutMs, async (response) => {
                    if (!response.ok) {
                        if (response.status === 401 || response.status === 403)
                            throw new ProviderError(name, 'auth', `HTTP ${response.status}`);
                        if (response.status === 400 || response.status === 422)
                            throw new ProviderError(name, 'bad_request', `HTTP ${response.status}`);
                        if (response.status === 429)
                            throw new ProviderError(name, 'rate_limit', `HTTP ${response.status}`);
                        if (response.status >= 500)
                            throw new ProviderError(name, 'server_error', `HTTP ${response.status}`);
                        throw new ProviderError(name, 'unknown', `HTTP ${response.status}`);
                    }
                    const body = response.body;
                    if (!body)
                        throw new ProviderError(name, 'invalid_response', 'response has no body');
                    const reader = body.getReader();
                    const decoder = new TextDecoder();
                    let buffer = '';
                    for (;;) {
                        const { done, value } = await reader.read();
                        if (value)
                            buffer += decoder.decode(value, { stream: true });
                        let newline = buffer.indexOf('\n');
                        while (newline >= 0) {
                            handleLine(buffer.slice(0, newline).replace(/\r$/, ''));
                            buffer = buffer.slice(newline + 1);
                            newline = buffer.indexOf('\n');
                        }
                        if (done)
                            break;
                    }
                    buffer += decoder.decode();
                    if (buffer.trim())
                        handleLine(buffer.trim());
                });
            }
            catch (err) {
                if (err instanceof ProviderError)
                    throw err;
                const kind = err instanceof Error && err.message === 'timeout' ? 'timeout'
                    : err instanceof Error && err.message === 'cancelled' ? 'cancelled' : 'network';
                throw new ProviderError(name, kind, kind === 'timeout' ? 'request timed out' : kind === 'cancelled' ? 'request cancelled' : 'request failed');
            }
            if (!content.trim()) {
                throw new ProviderError(name, 'invalid_response', 'missing assistant content');
            }
            if (!sawDone) {
                throw new ProviderError(name, 'invalid_response', 'stream ended without DONE');
            }
            return {
                content: content.trim(),
                provider: name,
                model: upstreamModel ?? model,
                usage: Object.keys(usage).length ? usage : undefined,
            };
        },
    };
}
