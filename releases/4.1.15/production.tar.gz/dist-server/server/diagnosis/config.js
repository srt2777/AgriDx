function boundedInteger(value, fallback, min, max) {
    if (!value?.trim())
        return fallback;
    const parsed = Number(value);
    return Number.isInteger(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
}
export function diagnosticRuntimeConfig() {
    const env = typeof process === 'undefined' ? {} : process.env;
    const agentLoopValue = env.AGENT_LOOP?.trim().toLowerCase();
    return {
        topK: boundedInteger(env.DIAGNOSIS_TOP_K, 5, 1, 20),
        contextMaxChars: boundedInteger(env.DIAGNOSIS_CONTEXT_MAX_CHARS, 8000, 1000, 32000),
        logDecisions: typeof process !== 'undefined' && env.DIAGNOSIS_LOG_DECISIONS?.trim() !== 'false',
        agentLoop: agentLoopValue === 'shadow' ? 'shadow' : agentLoopValue === 'main' ? 'main' : 'off',
    };
}
