/** Errors with a client-facing status/code; never include provider internals. */
export class VoiceError extends Error {
    status;
    code;
    constructor(status, code, message) {
        super(message);
        this.status = status;
        this.code = code;
        this.name = 'VoiceError';
    }
}
