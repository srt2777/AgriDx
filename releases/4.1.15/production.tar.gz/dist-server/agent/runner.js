import { ToolExecutor } from './tools';
import { canonical } from './tool-utils';
import { stripDsmlMarkup } from './dsml';
/** Experimental bounded read-only runner. Not connected to /api/chat. */
export async function runAgent(options) {
    const { provider, registry, signal } = options, toolEvents = [];
    const maxSteps = Math.max(1, Math.min(6, Math.floor(options.maxSteps ?? 4))), timeoutMs = Math.max(1, Math.min(120_000, options.timeoutMs ?? 60_000));
    if (signal?.aborted)
        return { status: 'cancelled', reason: 'cancelled', toolEvents };
    if (options.allowExternal !== true)
        return { status: 'fallback', reason: 'coordination_denied', toolEvents };
    if (!provider.isConfigured() || !provider.chatWithTools)
        return { status: 'fallback', reason: 'provider_unavailable', toolEvents };
    const controller = new AbortController(), cancel = () => controller.abort(), timer = setTimeout(cancel, timeoutMs);
    signal?.addEventListener('abort', cancel, { once: true });
    let rejectOnAbort = () => { };
    const interrupted = new Promise((_, reject) => { rejectOnAbort = () => reject(new Error('agent interrupted')); controller.signal.addEventListener('abort', rejectOnAbort, { once: true }); });
    void interrupted.catch(() => { });
    const executor = new ToolExecutor(registry);
    // Cross-step reuse cache, local to this run only: a successful tool
    // result from an earlier step is reused verbatim when a later step asks
    // the identical bound call again. It is never persisted, never shared
    // across runs or sessions, and never seeded from client input, so a stale
    // cross-turn result cannot leak into a new diagnosis turn (that wiring
    // remains an open gap, see the four-parts gaps doc). Failed results are
    // never cached, so a later retry still executes and the executor's
    // repeat rules still apply to retries.
    const crossStepCache = new Map();
    const sourceFor = (name) => ['search_research_knowledge', 'search_literature', 'search_knowledge', 'browse_knowledge', 'get_knowledge_entry', 'explore_relations', 'fault_chain', 'model_fault_index', 'maintenance_schedule'].includes(name) ? '混合资料' : name === 'calculator' || name === 'get_current_time' || name === 'knowledge_stats' ? '通识（无手册页码）' : name === 'resolve_machine_scope' || name === 'ask_user_for_info' ? '助手推断' : name === 'get_session_state' || name === 'list_prior_reports' ? '用户报告，待核实' : '未分类';
    const record = (step, offset) => { for (const event of executor.trace.slice(offset))
        toolEvents.push({ step, tool: event.tool, args: '[已脱敏]', ok: event.ok, error_type: event.error_type, duration_ms: event.duration_ms, source: sourceFor(event.tool) }); };
    try {
        const allowed = new Set(options.allowedTools.filter(name => registry.get(name)?.risk === 'read'));
        if (!allowed.has('resolve_machine_scope'))
            return { status: 'fallback', reason: 'scope_tool_unavailable', toolEvents };
        const scope = await executor.execute('resolve_machine_scope', { query: options.query, context: options.context ?? {} }, { signal: controller.signal });
        record(0, 0);
        if (!scope.ok)
            return { status: signal?.aborted ? 'cancelled' : 'fallback', reason: signal?.aborted ? 'cancelled' : controller.signal.aborted ? 'deadline' : scope.error_type ?? 'scope_failed', toolEvents };
        try {
            const parsed = JSON.parse(scope.content);
            if (parsed.identityConflict || parsed.ambiguous)
                return { status: 'fallback', reason: 'scope_conflict', toolEvents };
        }
        catch {
            return { status: 'fallback', reason: 'scope_invalid', toolEvents };
        }
        // Device identity is supplied by the host, never selected by the model.
        allowed.delete('resolve_machine_scope');
        const messages = [...options.messages, { role: 'system', content: `以下是服务端范围解析结果，仅供核对，不代表适用性或实车验证：${scope.content}` }];
        const definitions = registry.schemas([...allowed]);
        for (let step = 1; step <= maxSteps; step++) {
            if (controller.signal.aborted)
                return { status: signal?.aborted ? 'cancelled' : 'fallback', reason: signal?.aborted ? 'cancelled' : 'deadline', toolEvents };
            const forced = step === maxSteps;
            const reply = await Promise.race([provider.chatWithTools(messages, { tools: definitions, toolChoice: forced ? 'none' : 'auto', signal: controller.signal }), interrupted]);
            // Second layer for DSML: the provider translates well-formed DSML
            // blocks, but any provider (or a future one) may still return DSML
            // text as a final answer. Never let a tool-call markup block reach
            // the guard output or the user-visible supplement: strip it first,
            // and treat a reply that was only a tool call as rejected so the
            // service falls back to the single-call path instead of showing it.
            if (reply.toolCalls.length === 0) {
                const cleaned = stripDsmlMarkup(reply.content);
                if (!cleaned)
                    return { status: 'fallback', reason: 'answer_rejected', toolEvents };
                const safe = options.guard(cleaned);
                return safe ? { status: 'answered', content: safe, toolEvents } : { status: 'fallback', reason: 'answer_rejected', toolEvents };
            }
            if (forced || reply.toolCalls.length > 4 || reply.toolCalls.some(call => !allowed.has(call.name)))
                return { status: 'fallback', reason: 'disallowed_or_excess_tools', toolEvents };
            const question = reply.toolCalls.find(call => call.name === 'ask_user_for_info');
            if (question) {
                if (reply.toolCalls.length !== 1)
                    return { status: 'fallback', reason: 'mixed_control_call', toolEvents };
                const offset = executor.trace.length, result = await executor.execute(question.name, question.input, { signal: controller.signal });
                record(step, offset);
                if (!result.ok)
                    return { status: signal?.aborted ? 'cancelled' : 'fallback', reason: result.error_type ?? 'question_failed', toolEvents };
                const text = typeof question.input.question === 'string' ? options.guard(stripDsmlMarkup(question.input.question)) : null;
                return text ? { status: 'question', content: text, toolEvents } : { status: 'fallback', reason: 'answer_rejected', toolEvents };
            }
            const boundCalls = reply.toolCalls.map(call => {
                const input = { ...call.input };
                if (call.name === 'search_knowledge')
                    input.context = options.context ?? {};
                if (call.name === 'browse_knowledge') {
                    delete input.brand;
                    delete input.model;
                    if (typeof options.context?.brand === 'string')
                        input.brand = options.context.brand;
                    if (typeof options.context?.model === 'string')
                        input.model = options.context.model;
                }
                return { type: 'tool_use', id: call.id, name: call.name, input };
            });
            messages.push({ role: 'assistant', content: stripDsmlMarkup(reply.content), tool_calls: boundCalls.map(call => ({ id: call.id, type: 'function', function: { name: call.name, arguments: JSON.stringify(call.input) } })) });
            // Coordination, cross-step: identical calls already answered in an
            // earlier step reuse that step's successful result verbatim instead
            // of executing again, so a re-ask costs no executor time and no
            // repeat budget. Cached reuses produce no new trace event, exactly
            // like the same-turn dedup below; the provider still receives one
            // tool result per id it requested. Step count (maxSteps), the shared
            // wall-clock timeout, the allowlist, and the guard are unchanged:
            // reuse only replaces an execution the provider asked for again.
            const cachedById = new Map();
            const freshCalls = [];
            for (const call of boundCalls) {
                const hit = crossStepCache.get(`${call.name}:${canonical(call.input)}`);
                if (hit !== undefined)
                    cachedById.set(call.id, hit);
                else
                    freshCalls.push(call);
            }
            // Coordination: deduplicate identical calls within one turn AFTER
            // host binding, so a repeated call executes once and its result is
            // mapped back to every duplicate id. The provider still receives one
            // tool result per id it requested. This saves step/timeout budget
            // without changing executor semantics (repeat rejection, read-only
            // batching, guard, and fallback paths are untouched).
            const seenCalls = new Map();
            const uniqueCalls = [];
            const firstIdOf = new Map();
            for (const call of freshCalls) {
                const key = `${call.name}:${canonical(call.input)}`;
                if (seenCalls.has(key))
                    firstIdOf.set(call.id, seenCalls.get(key).id);
                else {
                    seenCalls.set(key, { id: call.id });
                    uniqueCalls.push(call);
                }
            }
            const offset = executor.trace.length;
            const uniqueResults = await executor.execute_tool_uses(uniqueCalls, { signal: controller.signal });
            record(step, offset);
            const resultById = new Map(uniqueResults.map(result => [String(result.tool_use_id), result]));
            for (const call of boundCalls) {
                const cached = cachedById.get(call.id);
                if (cached !== undefined) {
                    messages.push({ role: 'tool', tool_call_id: call.id, content: cached });
                    continue;
                }
                const result = resultById.get(firstIdOf.get(call.id) ?? call.id);
                if (result) {
                    messages.push({ role: 'tool', tool_call_id: call.id, content: String(result.content) });
                    // Only successful results enter the cross-step cache; an error
                    // result must not pin a later step to a stale failure.
                    if (!('is_error' in result))
                        crossStepCache.set(`${call.name}:${canonical(call.input)}`, String(result.content));
                }
            }
        }
        return { status: 'fallback', reason: 'step_budget', toolEvents };
    }
    catch {
        return { status: signal?.aborted ? 'cancelled' : 'fallback', reason: signal?.aborted ? 'cancelled' : controller.signal.aborted ? 'deadline' : 'provider_or_tool_error', toolEvents };
    }
    finally {
        clearTimeout(timer);
        signal?.removeEventListener('abort', cancel);
        controller.signal.removeEventListener('abort', rejectOnAbort);
    }
}
