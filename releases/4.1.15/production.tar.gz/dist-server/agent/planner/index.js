import { reducePlan, recordDecision } from './reducer';
import { decideNextAction } from './policy';
export { createPlan, reducePlan, PLANNER_LIMITS } from './reducer';
export { decideNextAction } from './policy';
/** Caller must thread the returned state. A proposal never acknowledges physical execution. */
export function advancePlan(state, context, event) {
    const updated = event ? reducePlan(state, event) : state;
    const decision = decideNextAction(updated, context);
    return { state: recordDecision(updated, decision), decision };
}
