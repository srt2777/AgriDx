export function trajectoryToSftExample(trajectory, rewardTotal) {
    if (!trajectory.answer.trim() || !trajectory.question.trim())
        return null;
    const messages = [
        { role: 'user', content: trajectory.question, train: true },
    ];
    for (const call of trajectory.toolCalls) {
        const evidence = call.evidenceIds.length > 0 ? `证据：${call.evidenceIds.join('、')}` : '证据：无';
        messages.push({
            role: 'tool',
            name: call.tool,
            content: `工具 ${call.tool} 已调用（${call.ok ? '成功' : '失败'}），结果已屏蔽，不计入 loss。${evidence}`,
            train: false,
        });
    }
    messages.push({ role: 'assistant', content: trajectory.answer, train: true });
    return {
        id: trajectory.id,
        topic: trajectory.plannerTopic,
        source: trajectory.source,
        rewardTotal,
        messages,
    };
}
export function sftExampleToJsonl(example) {
    return JSON.stringify(example);
}
/**
 * Export examples to JSONL, one example per line. Validates the masking
 * contract and throws instead of writing a bad file: every example must
 * have exactly one train:true assistant message, and every tool message
 * must be train:false.
 */
export function exportSftDataset(examples) {
    for (const example of examples) {
        const assistants = example.messages.filter(m => m.role === 'assistant' && m.train);
        if (assistants.length !== 1) {
            throw new Error(`SFT example ${example.id} must have exactly one trainable assistant message, got ${assistants.length}`);
        }
        const unmaskedTool = example.messages.find(m => m.role === 'tool' && m.train);
        if (unmaskedTool) {
            throw new Error(`SFT example ${example.id} has an unmasked tool message (${unmaskedTool.name ?? 'unknown'}); tool outputs must be masked`);
        }
        if (example.messages.some(m => m.role === 'tool' && /结果[：:]/i.test(m.content) && !m.content.includes('结果已屏蔽'))) {
            throw new Error(`SFT example ${example.id} leaks a tool result into the export`);
        }
    }
    return examples.map(sftExampleToJsonl).join('\n') + (examples.length > 0 ? '\n' : '');
}
