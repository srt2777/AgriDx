/** Measured values only: number + unit. Model names and evidence IDs never match. */
const MEASURED_NUMBER_RE = /-?\d+(?:\.\d+)?\s*(?:°C|℃|V|A|kPa|MPa|rpm|bar|%|mm|cm|m|km\/h)/g;
export function measuredNumbers(text) {
    return [...(text.match(MEASURED_NUMBER_RE) ?? [])].map(value => value.replace(/\s+/g, ''));
}
function asksUser(text) {
    return /[？?]|请.{0,12}(?:补充|确认|提供|检查)/.test(text);
}
function notesConflict(text) {
    return /冲突|不一致|不同说法|需要核对|尚不一致/.test(text);
}
/** Minimum total for a trajectory to count as a "good trajectory" for SFT. */
export const GOOD_TRAJECTORY_MIN_TOTAL = 6;
/** Flags that block the good-trajectory gate no matter the total. */
export const GOOD_TRAJECTORY_BLOCKING_FLAGS = ['bypass_tools', 'fabricated_number'];
export function isGoodTrajectory(breakdown) {
    return breakdown.total >= GOOD_TRAJECTORY_MIN_TOTAL
        && !breakdown.flags.some(flag => GOOD_TRAJECTORY_BLOCKING_FLAGS.includes(flag));
}
export function scoreTrajectory(trajectory, truth = {}) {
    const flags = [];
    let planner = 0;
    if (truth.expectedTopic !== undefined) {
        if (!trajectory.plannerUsed) {
            planner = -2;
            flags.push('planner_skipped');
        }
        else if (trajectory.plannerTopic === null) {
            planner = -1;
            flags.push('planner_unmatched');
        }
        else if (trajectory.plannerTopic === truth.expectedTopic) {
            planner = 2;
        }
        else {
            planner = -2;
            flags.push('planner_wrong_topic');
        }
    }
    let toolUse = 0;
    const expectedTools = truth.expectedTools ?? [];
    if (expectedTools.length > 0) {
        if (trajectory.toolCalls.length === 0) {
            toolUse = -3;
            flags.push('bypass_tools');
        }
        else {
            const usedOk = new Set(trajectory.toolCalls.filter(call => call.ok).map(call => call.tool));
            const missing = expectedTools.filter(tool => !usedOk.has(tool));
            if (missing.length === 0)
                toolUse = 2;
            else {
                toolUse = Math.max(-2, -missing.length);
                flags.push('tool_missing');
            }
        }
    }
    let numericCitation = 0;
    const answerNumbers = measuredNumbers(trajectory.answer);
    if (answerNumbers.length > 0) {
        if (trajectory.toolOutputs.length === 0) {
            numericCitation = 0;
            flags.push('numeric_unverifiable');
        }
        else {
            const outputText = trajectory.toolOutputs.map(output => output.text).join('\n');
            const outputNumbers = new Set(measuredNumbers(outputText));
            const uncited = answerNumbers.filter(value => !outputNumbers.has(value));
            if (uncited.length === 0)
                numericCitation = 1;
            else {
                numericCitation = -2;
                flags.push('fabricated_number');
            }
        }
    }
    let clarification = 0;
    if (truth.infoMissing) {
        if (asksUser(trajectory.answer))
            clarification = 1;
        else {
            clarification = -2;
            flags.push('hard_guess');
        }
    }
    let conflict = 0;
    if (truth.evidenceConflict) {
        if (notesConflict(trajectory.answer))
            conflict = 1;
        else {
            conflict = -1;
            flags.push('conflict_hidden');
        }
    }
    let diagnosis = 0;
    if (truth.expectedCauseText) {
        if (trajectory.answer.includes(truth.expectedCauseText))
            diagnosis = 2;
        else {
            diagnosis = -1;
            flags.push('diagnosis_missing');
        }
    }
    const total = planner + toolUse + numericCitation + clarification + conflict + diagnosis;
    return {
        planner,
        toolUse,
        numericCitation,
        clarification,
        conflict,
        diagnosis,
        total,
        flags,
        stepCredits: {
            planner,
            tool: toolUse,
            summary: numericCitation + clarification + conflict + diagnosis,
        },
    };
}
/**
 * GRPO-style offline group scoring (Lecture 9, checklist item 4): several
 * trajectories for the same question are scored against each other, not
 * against an absolute bar. Advantage is relative to the group mean, so a
 * merely average trajectory in a strong group earns ~0 and the best one
 * earns a positive advantage. No training happens here.
 */
export function scoreTrajectoryGroup(groupId, items) {
    if (items.length === 0)
        return { groupId, mean: 0, std: 0, scores: [], bestId: null };
    const mean = items.reduce((sum, item) => sum + item.total, 0) / items.length;
    const variance = items.reduce((sum, item) => sum + (item.total - mean) ** 2, 0) / items.length;
    const std = Math.sqrt(variance);
    const scores = items.map(item => ({
        id: item.id,
        total: item.total,
        advantage: std === 0 ? 0 : (item.total - mean) / std,
    }));
    const best = [...items].sort((a, b) => b.total - a.total)[0];
    return { groupId, mean, std, scores, bestId: best.id };
}
