const SECRET_PATTERNS = [
    /sk-[A-Za-z0-9_-]{8,}/g,
    /Bearer\s+[A-Za-z0-9._-]{8,}/gi,
    /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g,
    /(?<!\d)1[3-9]\d{9}(?!\d)/g,
    /[0-9a-f]{32,}/gi,
];
/** Redact secrets / contact-like strings from trajectory text. */
export function redactTrajectoryText(value) {
    if (typeof value !== 'string')
        return '';
    let out = value;
    for (const pattern of SECRET_PATTERNS)
        out = out.replace(pattern, '[已脱敏]');
    return out;
}
const MAX_TEXT_CHARS = 16000;
const MAX_TOOL_OUTPUT_CHARS = 2000;
function truncate(value, max) {
    return value.length > max ? `${value.slice(0, max)}…（已截断）` : value;
}
export function buildDiagnosticTrajectory(input) {
    const toolOutputs = (input.toolOutputs ?? []).map(output => ({
        tool: output.tool,
        text: truncate(redactTrajectoryText(output.text), MAX_TOOL_OUTPUT_CHARS),
    }));
    return {
        id: input.id ?? `traj-${Date.now().toString(36)}-${Math.floor(Math.random() * 0xffff).toString(16)}`,
        createdAt: input.createdAt ?? new Date().toISOString(),
        source: input.source ?? 'live-diagnosis',
        question: truncate(redactTrajectoryText(input.question), MAX_TEXT_CHARS),
        ...(input.machine ? { machine: { ...input.machine } } : {}),
        plannerTopic: input.plannerTopic ?? null,
        plannerUsed: input.plannerUsed ?? false,
        toolCalls: (input.toolCalls ?? []).map(call => ({ ...call })),
        toolOutputs,
        evidenceIds: [...(input.evidenceIds ?? [])],
        answer: truncate(redactTrajectoryText(input.answer), MAX_TEXT_CHARS),
        outcome: input.outcome ?? 'answered',
        route: input.route ?? '',
        reason: input.reason ?? '',
        usage: {
            rounds: input.usage?.rounds ?? 0,
            promptTokens: input.usage?.promptTokens ?? null,
            completionTokens: input.usage?.completionTokens ?? null,
            totalTokens: input.usage?.totalTokens ?? null,
            costUsd: input.usage?.costUsd ?? null,
        },
        correctness: input.correctness ?? 'unknown',
    };
}
