/** Public diagnosis modes and decisions, without server initialization. */
export const DIAGNOSIS_MODES = ['auto', 'knowledge_only', 'ai_assisted'];
export function isDiagnosisMode(value) {
    return typeof value === 'string' && DIAGNOSIS_MODES.includes(value);
}
