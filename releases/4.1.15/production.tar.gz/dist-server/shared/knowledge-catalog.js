export const KNOWLEDGE_ROLES = ['symptom', 'cause', 'check', 'action', 'retest'];
/** Disjoint browsing groups derived from existing index metadata, not new evidence. */
export const LIBRARY_KINDS = ['archive', 'general', 'terminology'];
export const CATALOG_FILTER_KEYS = ['brand', 'model', 'component', 'part', 'symptom', 'configuration', 'driveConfiguration', 'emissionStage', 'collection', 'kind', 'topic', 'entryType', 'q', 'page', 'role'];
export function validCatalogCondition(key, value) {
    if (key === 'configuration')
        return ['CAB', 'ROPS'].includes(value);
    if (key === 'driveConfiguration')
        return ['2WD', '4WD'].includes(value);
    if (key === 'emissionStage')
        return ['国三', '国四'].includes(value);
    if (key === 'collection')
        return ['all', 'archive', 'learning'].includes(value);
    if (key === 'kind')
        return LIBRARY_KINDS.includes(value);
    if (key === 'role')
        return KNOWLEDGE_ROLES.includes(value);
    if (key === 'page')
        return /^[1-9]\d{0,5}$/.test(value);
    return true;
}
/** 3.5.10起来源品牌统一为主品牌，子品牌/产品线另存；旧标签筛选仍映射到主品牌。 */
export const LEGACY_BRAND_LABELS = {
    雷沃欧豹: '雷沃',
    雷沃阿波斯: '雷沃',
    '千寻位置 / 千耘': '千寻位置',
};
export function canonicalCatalogBrand(brand) {
    return brand === undefined ? undefined : LEGACY_BRAND_LABELS[brand] ?? brand;
}
