export const TELEMETRY_WATERMARK = '仿真数据 / Simulated data';
export const DEMO_THRESHOLD_NOTE = '仿真演示阈值,非厂家标准';
export const TELEMETRY_WINDOWS = { '5m': 300000, '15m': 900000, '1h': 3600000 };
/** Only new samples update receivedAt; SSE heartbeats must not hide stale measurements. */
export function telemetryConnectionState(source, connected, receivedAt, now, staleAfterMs) {
    if (!connected)
        return 'offline';
    if (receivedAt === null || !Number.isFinite(receivedAt) || !Number.isFinite(now) || !Number.isFinite(staleAfterMs)
        || staleAfterMs <= 0 || now < receivedAt || now - receivedAt > staleAfterMs)
        return 'delayed';
    return source === 'device' ? 'live' : 'simulated';
}
