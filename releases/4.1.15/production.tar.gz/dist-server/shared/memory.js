/** Long-term memory: cross-session user-reported facts. Promoted never means verified. */
/** Max promoted long-term entries included in a prompt (kept in shared/memory so browser bundles never import the server SQLite store). */
export const LONG_TERM_PROMPT_MAX = 5;
