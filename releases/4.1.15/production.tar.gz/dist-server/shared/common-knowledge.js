/** Common organization is reusable; source-specific repair facts keep their original scope. */
export const KNOWLEDGE_STAGES = ['normal', 'symptom', 'cause', 'check', 'action', 'retest'];
/** Intake questions are prompts for missing facts, not confirmed machine conditions. */
export function buildCommonDiagnosisQuestion(symptom, configurationText) {
    return `${symptom.name}。${configurationText ? `已确认配置：${configurationText}。` : ''}请先核对本机资料和缺失的工况信息，再给出有来源的排查建议。`;
}
const record = (v) => !!v && typeof v === 'object' && !Array.isArray(v);
const text = (v) => typeof v === 'string' && !!v.trim();
const strings = (v) => Array.isArray(v) && v.every(text) && new Set(v).size === v.length;
const identity = (v) => record(v) && text(v.id) && text(v.name);
const stages = (v) => Array.isArray(v) &&
    v.length === KNOWLEDGE_STAGES.length && new Set(v.map(x => record(x) ? x.id : undefined)).size === v.length &&
    v.every(x => identity(x) && KNOWLEDGE_STAGES.includes(x.id));
const systems = (v) => Array.isArray(v) && v.length > 0 &&
    v.every(x => identity(x) && record(x) && strings(x.componentIds) && x.componentIds.length > 0 &&
        text(x.configurationNotes) && Array.isArray(x.performanceTargets) && x.performanceTargets.length > 0 && x.performanceTargets.every(identity));
const symptoms = (v) => Array.isArray(v) && v.length > 0 &&
    v.every(x => identity(x) && record(x) && strings(x.aliases) && strings(x.systemIds) && x.systemIds.length > 0 &&
        strings(x.performanceIds) && x.performanceIds.length > 0 && strings(x.questions) && x.questions.length > 0);
export function isCommonDefinition(v) {
    return record(v) && v.schemaVersion === 1 && text(v.purpose) && strings(v.questions) &&
        stages(v.stages) && systems(v.systems) && symptoms(v.symptoms) && Array.isArray(v.links) && v.links.every(x => record(x) && text(x.entryId) && strings(x.symptomIds) && strings(x.performanceIds) && x.performanceIds.length > 0 &&
        Array.isArray(x.stages) && x.stages.length > 0 && x.stages.every(s => record(s) &&
        KNOWLEDGE_STAGES.includes(s.id) && strings(s.evidenceTerms) && s.evidenceTerms.length > 0));
}
/** Validate server data before rendering the matrix or constructing diagnosis prompts. */
export function isCommonFramework(v) {
    if (!record(v) || v.schemaVersion !== 1 || !['archive', 'model'].includes(String(v.scope)) ||
        (v.selectedSymptom !== undefined && !text(v.selectedSymptom)) || !strings(v.questions) ||
        !stages(v.stages) || !systems(v.systems) || !symptoms(v.symptoms) || !Array.isArray(v.cells) ||
        ![v.linkedEntries, v.gapCells].every(x => typeof x === 'number' && Number.isSafeInteger(x) && x >= 0))
        return false;
    const targets = new Set(v.systems.flatMap(x => x.performanceTargets.map(p => p.id)));
    if (new Set(v.systems.map(x => x.id)).size !== v.systems.length ||
        new Set(v.symptoms.map(x => x.id)).size !== v.symptoms.length ||
        targets.size !== v.systems.flatMap(x => x.performanceTargets).length)
        return false;
    const keys = new Set();
    for (const cell of v.cells) {
        if (!record(cell) || !text(cell.performanceId) || !targets.has(cell.performanceId) ||
            !KNOWLEDGE_STAGES.includes(cell.stageId) || !strings(cell.entryIds) ||
            cell.status !== (cell.entryIds.length ? 'references' : 'gap'))
            return false;
        const key = `${cell.performanceId}/${cell.stageId}`;
        if (keys.has(key))
            return false;
        keys.add(key);
    }
    return keys.size === targets.size * KNOWLEDGE_STAGES.length &&
        v.linkedEntries === new Set(v.cells.flatMap(cell => cell.entryIds)).size &&
        v.gapCells === v.cells.filter(cell => cell.status === 'gap').length &&
        (v.selectedSymptom === undefined || v.symptoms.some(x => x.id === v.selectedSymptom));
}
