import fs from 'node:fs';
import path from 'node:path';
import { loadArchive } from './archive';
import { sha256Hex } from '../../shared/sha256';
import { buildKnowledgeCatalog } from './catalog-data';
import { configureIndexedModels } from './scope';
import { loadLearningEntries, learningChunks } from './learning';
import { buildRetrievalOrganization } from './common';
import { readSemanticReport } from '../../scripts/lib/semantic-report.mjs';
import { computeSnapshotSha256FromContents } from './snapshot-sha';
const KB_ROOT = path.resolve(process.cwd(), 'server/knowledge');
const INDEX_ROOT = path.resolve(process.cwd(), '知识库/整理后的知识库/农用拖拉机知识库');
let current;
/** Preserve the catalog's nullable metadata contract without request-time file reads. */
function readVersionMetadata() {
    try {
        const value = JSON.parse(fs.readFileSync(path.join(INDEX_ROOT, 'kb-version.json'), 'utf8')).kb_version;
        return typeof value === 'string' ? value : null;
    }
    catch {
        return null;
    }
}
/** Hash exactly the archived input community reports are built from: entries plus their hierarchy links. */
function computeKnowledgeSnapshotSha(chunks, entryComponents) {
    // Pure-TS SHA-256 (shared/sha256.ts): the hash must also work inside the
    // browser bundle, where node:crypto is externalized and unusable.
    const archived = chunks
        .filter((chunk) => chunk.entryId && chunk.diagnosticEvidence !== false)
        .map((chunk) => [chunk.entryId, chunk.sourceId, chunk.brand, chunk.model, chunk.models ?? null,
        chunk.entryType, chunk.locator, chunk.roles ?? null, chunk.roleBasis ?? null,
        chunk.riskLevel ?? null, chunk.riskBasis ?? null, chunk.pages ?? null, chunk.sourceTitle ?? null])
        .sort((a, b) => String(a[0]).localeCompare(String(b[0])));
    const links = Object.entries(entryComponents)
        .map(([entryId, components]) => [entryId, [...components].sort()])
        .sort((a, b) => a[0].localeCompare(b[0]));
    return sha256Hex(JSON.stringify(archived) + JSON.stringify(links));
}
/** Freeze plain data recursively so response consumers cannot corrupt cached evidence. */
function freezeData(value) {
    if (value && typeof value === 'object' && !Object.isFrozen(value)) {
        for (const child of Object.values(value))
            freezeData(child);
        Object.freeze(value);
    }
    return value;
}
function walkMdFiles(dir, base) {
    const out = [];
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const e of entries) {
        const full = path.join(dir, e.name);
        const rel = path.join(base, e.name);
        if (e.isDirectory()) {
            out.push(...walkMdFiles(full, rel));
        }
        else if (e.isFile() && e.name.endsWith('.md')) {
            out.push(rel);
        }
    }
    return out;
}
function splitByHeading(relPath, content) {
    const out = [];
    // 按 ## 切；文件首个 # 标题作为文件头，保留为 meta
    const lines = content.split(/\r?\n/);
    let currentHeading = '(概述)';
    let buf = [];
    const flush = () => {
        const text = buf.join('\n').trim();
        if (text.length > 0) {
            out.push({ source: relPath, heading: currentHeading, text });
        }
        buf = [];
    };
    for (const line of lines) {
        if (/^##\s+/.test(line)) {
            flush();
            currentHeading = line.replace(/^##\s+/, '').trim();
        }
        else {
            buf.push(line);
        }
    }
    flush();
    return out;
}
/** Read and validate everything before replacing any active consumer's data. */
export function reloadKnowledgeSnapshot() {
    const semanticBefore = readSemanticReport(process.cwd());
    const chunks = [];
    let fileCount = 0;
    for (const relative of walkMdFiles(KB_ROOT, '')) {
        if (relative.replace(/\\/g, '/').startsWith('00_说明/'))
            continue;
        chunks.push(...splitByHeading(relative.replace(/\\/g, '/'), fs.readFileSync(path.join(KB_ROOT, relative), 'utf8')));
        fileCount++;
    }
    const archive = loadArchive(undefined, { configureModels: false });
    // hierarchy.json 只读一次：原文既用于解析，也用于快照 SHA，不重读文件
    //（快照测试要求每个索引文件在一次加载里只读一次）。
    const hierarchyText = fs.readFileSync(path.join(INDEX_ROOT, 'hierarchy.json'), 'utf8');
    const hierarchy = JSON.parse(hierarchyText);
    const commonData = JSON.parse(fs.readFileSync(path.join(INDEX_ROOT, '通用框架.json'), 'utf8'));
    const learning = loadLearningEntries();
    freezeData(learning);
    const selectCatalog = buildKnowledgeCatalog(archive.chunks, archive.sources, hierarchy, commonData, learning);
    // buildKnowledgeCatalog already validates both structures. Reuse that generation,
    // without additional disk reads or an independent hierarchy/alias registry.
    const retrievalOrganization = freezeData(buildRetrievalOrganization(hierarchy.entries, commonData));
    const manualSourceIds = freezeData(archive.sources.filter(source => /整机|使用.*(?:说明|手册)|维修手册|保养说明书|保养手册/.test(source.document_type ?? ''))
        .map(source => source.source_id));
    // Passing records as arguments to push can overflow the stack on a large archive.
    for (const chunk of archive.chunks)
        chunks.push(chunk);
    for (const chunk of learningChunks(learning))
        chunks.push(chunk);
    freezeData(chunks);
    const baseCatalog = freezeData(selectCatalog());
    const kbVersion = readVersionMetadata();
    // 快照 SHA 用加载时已读入内存的三份索引原文算，不再重读文件。
    const snapshotSha256 = computeSnapshotSha256FromContents({
        'hierarchy.json': hierarchyText,
        'entries.jsonl': archive.indexTexts['entries.jsonl'],
        'sources.json': archive.indexTexts['sources.json'],
    });
    const catalog = freezeData({ ...baseCatalog, kbVersion, snapshotSha256 });
    const semanticAfter = readSemanticReport(process.cwd());
    const semantic = JSON.stringify(semanticBefore) === JSON.stringify(semanticAfter) ? semanticAfter : { reason: '载入知识快照期间语义审核报告或来源发生变化。' };
    const entryNodes = new Map();
    const sourceModels = new Map(archive.sources.map(source => [source.source_id, source.model]));
    const entryModels = new Map();
    for (const chunk of archive.chunks) {
        if (!chunk.entryId)
            continue;
        const models = chunk.models ?? [sourceModels.get(chunk.sourceId)].filter((model) => Boolean(model));
        entryModels.set(chunk.entryId, Object.freeze(models));
    }
    if (semantic.report) {
        const byEntry = new Map(hierarchy.entries.map(item => [item.entry_id, item.components]));
        for (const chunk of archive.chunks) {
            if (!chunk.entryId || !chunk.brand || !chunk.sourceId)
                continue;
            const models = entryModels.get(chunk.entryId) ?? [];
            const ids = [];
            for (const model of models)
                for (const item of byEntry.get(chunk.entryId) ?? []) {
                    if (item.part_ids.length)
                        ids.push(...item.part_ids.map(part => JSON.stringify([chunk.brand, model, item.component_id, part])));
                    else
                        ids.push(JSON.stringify([chunk.brand, model, item.component_id]));
                }
            entryNodes.set(chunk.entryId, ids);
        }
    }
    const next = Object.freeze({
        kbVersion, snapshotSha256, snapshotSha: computeKnowledgeSnapshotSha(archive.chunks, retrievalOrganization.entryComponents), entryModels,
        chunks, fileCount: fileCount + archive.fileCount + new Set(learning.map(entry => entry.knowledgePath)).size, archivedEntries: archive.chunks.length,
        learningEntries: learning.length,
        retrievalOrganization, manualSourceIds, semantic: { ...semantic, entryNodes },
        getCatalog: (filters = {}) => {
            const selected = selectCatalog(filters);
            return selected === baseCatalog ? catalog : freezeData({ ...selected, kbVersion, snapshotSha256 });
        },
    });
    // The archive loader's standalone API still configures models by default. Here it
    // is deferred until hierarchy/catalog validation succeeds, preserving old scope
    // recognition as well as old data when any input is invalid.
    configureIndexedModels(archive.chunks);
    current = next;
    return next;
}
export function loadKnowledgeSnapshot() {
    return current ?? reloadKnowledgeSnapshot();
}
export function peekKnowledgeSnapshot() { return current; }
