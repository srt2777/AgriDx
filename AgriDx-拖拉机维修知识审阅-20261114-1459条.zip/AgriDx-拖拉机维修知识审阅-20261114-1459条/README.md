# AgriDx 拖拉机维修知识审阅包

目标新增 300,000 条。当前 1459 条已通过隔离索引及 Agent 编号检索，1459 条在按型号与标题检索时排第一。正式入库 0 条。

- ISEKI 601 条
- 约翰迪尔 303 条
- TYM 115 条
- 洋马 78 条
- Belarus 65 条
- KIOTI 64 条
- Farmtrac 59 条
- 久保田 44 条
- 纽荷兰 44 条
- LS Tractor 41 条
- Branson 28 条
- Mahindra 16 条
- DEUTZ 1 条

- [逐条改动计划及原文位置](改动计划.md)
- [合并检索验证](合并检索验证.json)
- [隔离索引校验](summary.json)

- 5 条同型号手册跨版本矛盾已排除。 [逐条差异](Farmtrac-跨版本冲突.md)