# OPERATOR'S MANUAL T SERIES Direct

- 仅 Valtra T5 Direct 本册列出的完整 2A1 型号 T145D、T155D、T175ED、T195D、T215D、T235D。维修时核对铭牌完整型号及对应实车装配。
- [原厂 PDF](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1D1101B_VT_T5_EN.pdf)

## KB-VALTRA-T5-DIRECT-M1212A1D1101B-006｜Direct 起步冲击时核对涡轮离合模拟设置

- 适用条件：仅 Valtra T5 Direct 本册列出的完整 2A1 型号 T145D、T155D、T175ED、T195D、T215D、T235D。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：Direct 起步冲击时核对涡轮离合模拟设置。
- 诊断步骤：本册所述涡轮离合模拟用于减小牵引冲击，尤其是地面湿滑或负载较重时。按相应版本 SmartTouch 的传动附加设置核对离合选项和是否启用，保留实际工况与起步冲击表现交维修人员判断。
- 证据：SRC-VALTRA-T5-DIRECT-M1212A1D1101B；PDF物理第249页；印刷页脚 254；Direct 起步冲击时核对涡轮离合模拟设置。[原厂 PDF 第249页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1D1101B_VT_T5_EN.pdf#page=249)

