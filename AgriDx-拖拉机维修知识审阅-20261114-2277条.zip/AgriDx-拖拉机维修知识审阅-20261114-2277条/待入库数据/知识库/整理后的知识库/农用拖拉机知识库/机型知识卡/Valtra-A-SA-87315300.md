# Manual del Operador Tractor serie A

- 仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- [原厂 PDF](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf)

## KB-VALTRA-A-SA-87315300-001｜运行温度过低时检查节温器卡在开启位置

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：运行温度过低时检查节温器卡在开启位置。
- 诊断步骤：原厂温度偏低排查表列节温器卡在开启位置，并说明缺少防腐添加剂可能有关。依本机规定检查防腐冷却液及节温器；另列喷油正时异常需交授权维修核对。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第163页；印刷页脚 163；运行温度过低时检查节温器卡在开启位置。[原厂 PDF 第163页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=163)

## KB-VALTRA-A-SA-87315300-002｜柴油机反复熄火时核对断油电磁阀供油和通气

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：柴油机反复熄火时核对断油电磁阀供油和通气。
- 诊断步骤：本册把喷油泵上的停机控制电磁阀及电连接列入反复停机排查，同时列输油泵、滤芯堵塞和燃油进气。下一印刷页补列油箱盖通气堵塞、燃油含水及曲轴箱通气管堵塞。按工况分支核对，逐项处理实查发现。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第163页；印刷页脚 163；柴油机反复熄火时核对断油电磁阀供油和通气。[原厂 PDF 第163页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=163)

## KB-VALTRA-A-SA-87315300-003｜油耗偏高时分辨温度、配套农具和供油异常

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：油耗偏高时分辨温度、配套农具和供油异常。
- 诊断步骤：原厂除燃油和空气滤芯堵塞外，还列发动机运行温度偏低、农具不匹配或调整不当、燃油含水、曲轴箱通气阻塞，以及喷油泵、喷嘴、喷油正时或气门间隙异常。先核对温度、作业负荷与滤芯，喷射部件由授权维修检查。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第164页；印刷页脚 164；油耗偏高时分辨温度、配套农具和供油异常。[原厂 PDF 第164页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=164)

## KB-VALTRA-A-SA-87315300-004｜发动机内部敲击时核对油位和飞轮等来源

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：发动机内部敲击时核对油位和飞轮等来源。
- 诊断步骤：原表把机油液位不正确、飞轮松动、机油泵及内部磨损与内部敲击列在同一故障分支，并列喷油和气门间隙因素。先停机按标尺查机油，维修人员按观察确认声源再检查内部。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第165页；印刷页脚 165；发动机内部敲击时核对油位和飞轮等来源。[原厂 PDF 第165页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=165)

## KB-VALTRA-A-SA-87315300-005｜曲轴箱压力过高时检查呼吸管堵塞

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：曲轴箱压力过高时检查呼吸管堵塞。
- 诊断步骤：原厂把曲轴箱呼吸管堵塞列为检查对象。先按停机维修程序检查通气管；若通畅仍有过压，原册还列气缸套、活塞环、气门导管或气门杆密封异常，应由授权维修检查。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第165页；印刷页脚 165；曲轴箱压力过高时检查呼吸管堵塞。[原厂 PDF 第165页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=165)

## KB-VALTRA-A-SA-87315300-006｜机油压力低时核对油量、压力显示和机油泵

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：机油压力低时核对油量、压力显示和机油泵。
- 诊断步骤：原表列油底壳油量低、润滑油不合规格、机油泵或其泄压阀故障，以及显示异常。安全停机后查机油量和规格。显示与实测结果需要核对，机油泵相关问题交授权维修处理。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第166页；印刷页脚 166；机油压力低时核对油量、压力显示和机油泵。[原厂 PDF 第166页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=166)

## KB-VALTRA-A-SA-87315300-007｜排气白烟时核对燃油和运行温度

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：排气白烟时核对燃油和运行温度。
- 诊断步骤：本册西语故障表将不合规格的燃油和发动机运行温度偏低列为白烟候选。记录白烟是否持续到温机、燃油是否与规定相符，按本机程序处理。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第166页；印刷页脚 166；排气白烟时核对燃油和运行温度。[原厂 PDF 第166页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=166)

## KB-VALTRA-A-SA-87315300-008｜排气蓝烟时核对呼吸管和润滑油

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：排气蓝烟时核对呼吸管和润滑油。
- 诊断步骤：原表列机油规格不合、呼吸管堵塞、缸套和活塞环磨损、气门导管磨损以及喷油系统异常。停机先按本册核对油品及呼吸管，内部检查交授权维修。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第166页；印刷页脚 166；排气蓝烟时核对呼吸管和润滑油。[原厂 PDF 第166页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=166)

## KB-VALTRA-A-SA-87315300-011｜熔丝和灯泡反复烧毁时检查短路和过充

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：熔丝和灯泡反复烧毁时检查短路和过充。
- 诊断步骤：原厂列线路对地短路、充电调节异常导致蓄电池过充，以及灯泡或附件超出规格或挤在一个熔丝回路。由维修人员按本机电路确认原因和额定值。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第168页；印刷页脚 168；熔丝和灯泡反复烧毁时检查短路和过充。[原厂 PDF 第168页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=168)

## KB-VALTRA-A-SA-87315300-012｜轮胎严重打滑时核对配重、农具和胎面规格

- 适用条件：仅 Valtra 87315300 南美西语原册列出的 A650、A750、A750L、A850、A950、A990。核对本车铭牌、发动机及所装零部件。
- 故障现象：轮胎严重打滑时核对配重、农具和胎面规格。
- 诊断步骤：先依据原厂故障表核对前后桥配重分配、农具匹配和调整，以及轮胎磨损或胎面不适合当前土壤。原表区分低承载地与坚实地的胎面需求，不能把单一胎压设到所有轮胎上。
- 证据：SRC-VALTRA-A-SA-87315300；PDF物理第168页；印刷页脚 168；轮胎严重打滑时核对配重、农具和胎面规格。[原厂 PDF 第168页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/Tractores-Valtra-Linea-A.pdf#page=168)

