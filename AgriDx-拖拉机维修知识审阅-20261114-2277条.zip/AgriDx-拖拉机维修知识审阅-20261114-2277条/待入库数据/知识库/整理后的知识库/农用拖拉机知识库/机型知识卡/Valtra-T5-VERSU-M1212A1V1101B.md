# OPERATOR'S MANUAL T SERIES Versu

- 仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- [原厂 PDF](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-001｜发动机限转或短延时停机时核对保护状态

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：发动机限转或短延时停机时核对保护状态。
- 诊断步骤：本册列出某些维修报码可将最高转速限制在例如 1500 或 1800 rpm，或限制扭矩与功率，还可能约 30 秒后停机。遇到这种现象要记录显示与触发工况，出现闪烁 STOP 灯应立即安全停机，再联系授权维修核对活动报码。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第526页；印刷页脚 531；发动机限转或短延时停机时核对保护状态。[原厂 PDF 第526页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=526)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-004｜变速箱过热时核对两处油温显示

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：变速箱过热时核对两处油温显示。
- 诊断步骤：本册要求在出现变速箱过热提示后停止作业，让变速箱降到规定工作温度。A 柱显示屏和 SmartTouch 都显示变速箱温度，维修时可记录两处读数及报警发生工况。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第528页；印刷页脚 533；变速箱过热时核对两处油温显示。[原厂 PDF 第528页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=528)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-007｜燃油压力低时检查低压滤清器结冰或堵塞

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：燃油压力低时检查低压滤清器结冰或堵塞。
- 诊断步骤：出现低燃油压力弹窗时，手册优先检查燃油滤清器是否冰堵或污堵。记录天气、是否冷启动，以及仪表信息，再按本机程序检查燃油低压侧。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第529页；印刷页脚 534；燃油压力低时检查低压滤清器结冰或堵塞。[原厂 PDF 第529页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=529)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-008｜液压油温高及单次蜂鸣时查冷却器和油位

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：液压油温高及单次蜂鸣时查冷却器和油位。
- 诊断步骤：原厂将液压油温高与一次蜂鸣配对。停机后按手册清洁液压油冷却器并核对液压油位。与变速箱温度告警应按不同回路定位。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第530页；印刷页脚 535；液压油温高及单次蜂鸣时查冷却器和油位。[原厂 PDF 第530页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=530)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-009｜燃油含水弹窗后先核查预滤器

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：燃油含水弹窗后先核查预滤器。
- 诊断步骤：该原厂表要求先检查燃油预滤器是否积水。若预滤器里确有水，按本册维修程序排放并清洁油箱。记录屏幕提示和预滤器实查结果。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第530页；印刷页脚 535；燃油含水弹窗后先核查预滤器。[原厂 PDF 第530页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=530)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-010｜行驶灯故障伴近光与车顶前灯点亮

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：行驶灯故障伴近光与车顶前灯点亮。
- 诊断步骤：原厂手册把这一警告与组合操纵杆异常关联。发生时可同时观察到发动机罩附近近光和车顶前工作灯亮起。记录组合操纵杆表现和灯光组合，供维修人员查对应线路。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第530页；印刷页脚 535；行驶灯故障伴近光与车顶前灯点亮。[原厂 PDF 第530页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=530)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-012｜变速箱低油压 STOP 弹窗的处置

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：变速箱低油压 STOP 弹窗的处置。
- 诊断步骤：本册把低变速箱油压列为 STOP 弹窗。原厂要求停止发动机，立即联系授权维修；记录相关指示及触发时机，保留低油压与滤芯堵塞两个报警名称。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第532页；印刷页脚 537；变速箱低油压 STOP 弹窗的处置。[原厂 PDF 第532页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=532)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-013｜SmartTouch 书本图标闪烁时查看活动维修报码

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：SmartTouch 书本图标闪烁时查看活动维修报码。
- 诊断步骤：从 SmartTouch 首页进入 Tractor Health。原厂图例显示活动报码在侧栏，分 SPN、FMI、SA 三列。记录三个字段与当时的图标和症状。图中的数字仅用于示例显示，不提供故障释义。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第533页；印刷页脚 538；SmartTouch 书本图标闪烁时查看活动维修报码。[原厂 PDF 第533页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=533)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-014｜液压和变速箱滤芯堵塞的壳体标识及对应更换

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：液压和变速箱滤芯堵塞的壳体标识及对应更换。
- 诊断步骤：原厂图示三个滤芯在驾驶室下方右侧。弹窗提示辅助液压回油滤芯堵塞对应 HYD；提示传动油滤芯堵塞则核对润滑滤芯 LUB 和低压滤芯 TRANS，两件同规格，原厂要求一起更换。油温正常时才监测堵塞；提前堵塞应由维修人员追查传动系统原因。见正文图 3 至图 5。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第534页；印刷页脚 539；液压和变速箱滤芯堵塞的壳体标识及对应更换。[原厂 PDF 第534页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=534)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-019｜低温雪尘环境下风扇碰击导风罩冰雪

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：低温雪尘环境下风扇碰击导风罩冰雪。
- 诊断步骤：在气温低于 −15 °C 且空气雪尘很多时，原厂要求每 4 小时或更频繁检查风扇区域。冬季风扇异响可先停机检查风扇与导风罩之间堆积的冰雪；原厂图规定停机后用木或塑料刮具清除导风罩堆积。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第545页；印刷页脚 550；低温雪尘环境下风扇碰击导风罩冰雪。[原厂 PDF 第545页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=545)

## KB-VALTRA-T5-VERSU-M1212A1V1101B-020｜液压供油失效时转向异常变重

- 适用条件：仅 Valtra T5 Versu 本册列出的完整 2A1 型号 T145V、T155V、T175EV、T195V、T215V、T235V、T255V。维修时核对铭牌完整型号及对应实车装配。
- 故障现象：液压供油失效时转向异常变重。
- 诊断步骤：本册描述供油失效时转向阀为转向油缸提供应急液压，方向盘操作会明显变重。发生转向功能异常应安全停车，排除故障后才可重新启动。将供油状态和转向表现交授权人员核查。
- 证据：SRC-VALTRA-T5-VERSU-M1212A1V1101B；PDF物理第546页；印刷页脚 551；液压供油失效时转向异常变重。[原厂 PDF 第546页](https://apps.valtradev.com/resources/my-valtra-machine/1/OM_M1212A1V1101B_VT_T5_EN.pdf#page=546)

