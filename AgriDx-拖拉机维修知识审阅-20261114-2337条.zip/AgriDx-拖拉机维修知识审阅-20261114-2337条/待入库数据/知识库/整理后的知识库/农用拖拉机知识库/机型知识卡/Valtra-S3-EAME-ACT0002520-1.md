# VALTRA_S3 — 4. Mantenimiento

- 仅 Valtra S3 EAME 原册 ACT0002520 版 1 所列 S233、S263、S293、S323、S353，按原厂表的配套总成、仪表来源及控制器核对。
- [原厂 PDF](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/l%C3%ADnea-s/Serie-S-Mantenimiento.pdf)

## KB-VALTRA-S3-EAME-ACT0002520-1-001｜DOT Matrix 显示与自动空调专用故障显示

- 适用条件：仅 Valtra S3 EAME 原册 ACT0002520 版 1 所列 S233、S263、S293、S323、S353，按原厂表的配套总成、仪表来源及控制器核对。
- 故障现象：DOT Matrix 显示与自动空调专用故障显示。
- 诊断步骤：S3 EAME 原表说明常规故障由仪表 DOT Matrix 显示组件字母或图标，自动空调报码显示在空调模块。排查前记录显示位置及完整字母数字，按对应系统查表。
- 证据：SRC-VALTRA-S3-EAME-ACT0002520-1；PDF物理第72页；印刷页脚 312；DOT Matrix 显示与自动空调专用故障显示。[原厂 PDF 第72页](https://www.valtra.com/content/dam/public/valtra/es-ar/pos-venda/manuales-del-operador/l%C3%ADnea-s/Serie-S-Mantenimiento.pdf#page=72)

