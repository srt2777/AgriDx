# Farmtrac 跨版本复核

下列判断保留在工作区。相同型号在两种语言出版物中的部件设置或数据有差异，需要用厂家或实车编号证实适用版本。

| 状态 | 知识编号 | 英文原件物理页及内容 | 波兰语原件物理页及内容 |
| --- | --- | --- | --- |
| 待核对 | KB-FARMTRAC-6100-DTV-PWR-181-003 | 181 第 58 页表 5，传动共用 API GL-4 10W-40，前桥 API GL-5 85W-90 | 178 第 55 页表 5，传动共用 API GL-5 15W-30，前桥 API GL-5 80W-90 |
| 待核对 | KB-FARMTRAC-6100-DTV-PWR-181-007 | 181 第 70 页 5.9 节，两只液压油滤芯均每 300 小时 | 178 第 68 页 5.9 节，细滤芯首次 50、随后每 300 小时，粗滤芯随传动油 900 小时或每年更换 |
| 待核对 | KB-FARMTRAC-9100-9130-DTV-216-010 | 216 第 74 页 5.7.3 节，后轮轮辋至轮盘 144 N·m | 212 第 64 页 5.7.3 节，后轮轮辋至轮盘 244 N·m |
| 待核对 | KB-FARMTRAC-9100-9130-DTV-216-012 | 216 第 75–76 页 5.9 节，两只液压滤芯均每 300 小时，传动和后桥油 1200 小时或每年 | 212 第 66 页 5.9 节，细滤芯首次 50、随后每 300 小时，粗滤芯随油 900 小时或每年更换 |
| 待核对 | KB-FARMTRAC-9100-9130-DTV-216-013 | 216 第 76 页 5.11 节，常规驾驶室滤芯 300 小时 | 212 第 67 页 5.11 节，常规驾驶室滤芯 50 小时 |
| 继续可用 | KB-FARMTRAC-6100-DTV-PWR-181-008 | 181 第 71 页 5.11 节，常规驾驶室滤芯 150 小时，高尘时 10 小时或每日 | 178 第 68 页 5.11 节，常规驾驶室滤芯 150 小时，高尘时缩短周期 |

- [6100 DT V PWR 英文原件 181](https://farmtrac.pl/wp-content/uploads/2020/09/OM-FT-6100DT-V-PWR.pdf)，SHA-256 `1b6e042566b30d39dc616b6ddad68322766cc624dbb8b3047fe74b616a36d584`。
- [6100 DT V PWR 波兰语原件 178](https://farmtrac.pl/wp-content/uploads/2020/06/Instrukcja-obslugi-6100-DT-V-PWR-Euro-5.pdf)，SHA-256 `c0b8c8e7dad32f54207534f242d726d2f4ada834cbcd6d995c3acb4b2871c3ea`。
- [9100–9130 DT V 英文原件 216](https://farmtrac.pl/wp-content/uploads/2020/09/FT9100_9120_FT9130-DT-V-OPERATORS-MANUAL-i.I.pdf)，SHA-256 `52ff16648a73ac7b430bec65e78d97670d2b94d94a349a092d2920c0d224d0fe`。
- [9100–9130 DT V 波兰语原件 212](https://farmtrac.pl/wp-content/uploads/2024/04/Instrukcja-FARMTRAC-FT9100_9120_FT9130-DT-V-w.-I.pdf)，SHA-256 `05671057e4ea2791918222a51bfbb246bd6418bae89119cdbd2f141af71c3fb1`。

既有独立版本 217（6100 DT V 机械变速）和 214（9100–9130 DT V PWR）按各自封面型号与手册保留。主管工况不明时需要精确型号和手册版次。
