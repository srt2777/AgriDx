# MISTRAL AMERICA 40 - 45 - 50 TRAINING MANUAL

- 仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- [原厂 PDF](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-001｜行驶离合器打滑的摩擦副和中间碟簧排查

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：行驶离合器打滑的摩擦副和中间碟簧排查。
- 诊断步骤：300 节 LX 9／9 双干式离合表列三条路径：摩擦片、压盘或飞轮超限磨损；碟形弹簧拉伸或损坏；摩擦材料沾油。维修人员按分册规格测量及调校，处理漏油来源并清洁摩擦面，必要时更换污染件或磨损件。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第143页；原册定位 300-6（分册目录）；行驶离合器打滑的摩擦副和中间碟簧排查。[原厂 PDF 第143页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=143)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-002｜离合器接合冲击时检查外连杆与摩擦片

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：离合器接合冲击时检查外连杆与摩擦片。
- 诊断步骤：300 节将外部操纵铰点发涩、离合器片翘曲、摩擦面沾油列为不同原因。先查外部铰点并润滑；确认翘曲则更换离合器片并调操纵；确认油污染还要排除渗漏并清洁摩擦面。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第143页；原册定位 300-6（分册目录）；离合器接合冲击时检查外连杆与摩擦片。[原厂 PDF 第143页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=143)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-003｜离合器分离拖滞的操纵与摩擦片检查

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：离合器分离拖滞的操纵与摩擦片检查。
- 诊断步骤：300 节列外部操纵卡滞、调节不当及离合片翘曲。维修人员检查铰点和控制行程，修复卡滞部件，再按原册 300-18 的相应调整检查。离合片翘曲时按拆装章节更换并调节。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第143页；原册定位 300-6（分册目录）；离合器分离拖滞的操纵与摩擦片检查。[原厂 PDF 第143页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=143)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-004｜踩放离合器出现异响时核查推力轴承和盘簧

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：踩放离合器出现异响时核查推力轴承和盘簧。
- 诊断步骤：原厂故障表区分推力轴承磨损和离合器盘弹簧异常。按 300 节定位并确认哪个件已损坏，再更换经检查确认的轴承或离合器盘。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第143页；原册定位 300-6（分册目录）；踩放离合器出现异响时核查推力轴承和盘簧。[原厂 PDF 第143页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=143)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-005｜离合踏板过重先查外部铰接点

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：离合踏板过重先查外部铰接点。
- 诊断步骤：先分别检查离合操纵机构的铰接点与踏板本身的铰接点是否发涩。原表对应处理为检查和润滑 300 节所示外部转动部位，再复核踏板动作。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第143页；原册定位 300-6（分册目录）；离合踏板过重先查外部铰接点。[原厂 PDF 第143页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=143)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-006｜机械变速箱或换向器自行脱挡

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：机械变速箱或换向器自行脱挡。
- 诊断步骤：400 节列 12＋12、16＋16 通用机械箱/换向器自行脱挡。先查外操纵拉杆或操纵杆调整及接合行程，确认定位弹簧有无故障；排除外部原因后再按分册检查同步接合齿或套筒的损坏。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第166页；原册定位 400-8；机械变速箱或换向器自行脱挡。[原厂 PDF 第166页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=166)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-007｜机械换挡或换向难接合的检查

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：机械换挡或换向难接合的检查。
- 诊断步骤：先检查操纵杆调整、铰接发涩或卡滞，以及行驶离合分离拖滞。原表另列同步器或接合套异常，以及内部控制杆、拨叉和套筒滑动不畅；确认内件故障后才按 400 节拆检。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第166页；原册定位 400-8；机械换挡或换向难接合的检查。[原厂 PDF 第166页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=166)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-010｜空挡滑行时后桥中央仍有异响

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：空挡滑行时后桥中央仍有异响。
- 诊断步骤：先定位声源是否为中央差速器。500 节在排除左右终传动后列差速器齿轮调整不当或磨损，以及半轴与齿轮连接槽配合间隙过大。由维修人员拆检后桥，确认磨损件并按分册调整差速器。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第194页；原册定位 500-9（分册目录）；空挡滑行时后桥中央仍有异响。[原厂 PDF 第194页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=194)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-011｜后桥噪声伴过热时检查锥齿轮副齿侧隙

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：后桥噪声伴过热时检查锥齿轮副齿侧隙。
- 诊断步骤：500 节将主动小锥齿轮与从动锥齿圈啮合间隙不足列为后桥噪声伴发热的一项原因。由维修人员查齿侧间隙并按该分册调校齿圈支承轴承。分册物理第189页给出本总成齿侧隙 0.15–0.22 mm。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第194页；原册定位 500-9（分册目录）；后桥噪声伴过热时检查锥齿轮副齿侧隙。[原厂 PDF 第194页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=194)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-012｜空挡滑行时侧终传动一侧发响

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：空挡滑行时侧终传动一侧发响。
- 诊断步骤：声源在侧终传动时，500 节另列侧减速内部件损伤或轮轴与侧终传动连接槽间隙过大。由维修人员拆检发声一侧的侧终传动壳体并更换确认损坏件。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第194页；原册定位 500-9（分册目录）；空挡滑行时侧终传动一侧发响。[原厂 PDF 第194页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=194)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-015｜机械 PTO 带负载打滑掉转

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：机械 PTO 带负载打滑掉转。
- 诊断步骤：600 节故障表列 PTO 离合器操纵杆调整不良、摩擦片或飞轮压紧面磨损。停机并隔离农具后查操纵行程，由维修人员按 300 和 600 节确认调整或磨损。离合器部件超过维修限值时更换。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第262页；原册定位 600-8（分册目录）；机械 PTO 带负载打滑掉转。[原厂 PDF 第262页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=262)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-016｜机械 PTO 转速选择杆发涩

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：机械 PTO 转速选择杆发涩。
- 诊断步骤：原表列转速选择杆的外部操纵发涩或调整不当。停机、断开动力输入后，对照图 6 核实选速连杆的活动和调整，由维修人员润滑和调整对应操纵机构。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第262页；原册定位 600-8（分册目录）；机械 PTO 转速选择杆发涩。[原厂 PDF 第262页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=262)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-018｜行驶离合踏板的调节行程

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：行驶离合踏板的调节行程。
- 诊断步骤：300 节图 32–34 给出踏板调整检查为 15–25 mm。由维修人员在停机条件下检查拉索端叉和固定销，调至图示行程，再锁紧螺母并确认操纵动作。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第155页；原册定位 300-18（分册目录）；行驶离合踏板的调节行程。[原厂 PDF 第155页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=155)

## KB-LANDINI-MISTRAL-AMERICA-3676163M1-019｜机械 PTO 离合手柄空行程调整

- 适用条件：仅 Landini Mistral America 40／45／50 的 3676163M1 2004-07 版，按实车总成核对，由维修人员作业。
- 故障现象：机械 PTO 离合手柄空行程调整。
- 诊断步骤：300 节图 35–36 是 PTO 离合调节，空行程应为 25–30 mm。虽然英语文字误称踏板，图 36 画的是手柄，300-3 规格同样指明 PTO 离合手控。由维修人员核实图示测量点并调整锁紧件。
- 证据：SRC-LANDINI-MISTRAL-AMERICA-3676163M1；PDF物理第156页；原册定位 300-19（分册目录）；机械 PTO 离合手柄空行程调整。[原厂 PDF 第156页](https://truckmanualshub.com/files/853cb32c59e9197cdc3d08f0ccd22614aa586266a9f39bf39322cb88c4704d7a.pdf#page=156)

