# Landpower TDI Operation and maintenance manual

- 仅 2005 年 Landini 3681 715 M1 所列 Landpower 125／135／145／165／185 TDI，核对铭牌与实车装配。
- [原厂 PDF](https://truckmanualshub.com/files/c96552feff1a3e458568c1480bd83d80cc489d63a377a55e2d02767ae960a924.pdf)

## KB-LANDINI-LANDPOWER-TDI-3681715M1-033｜冷却水温进入红区的检查顺序

- 适用条件：仅 2005 年 Landini 3681 715 M1 所列 Landpower 125／135／145／165／185 TDI，核对铭牌与实车装配。
- 故障现象：冷却水温进入红区的检查顺序。
- 诊断步骤：本册列高温指示灯约在 105–110 °C 亮起。发现温度过高立即卸载怠速，表针仍在红区则查冷却液液位、散热器泥草堵塞、水路沉积、风扇皮带松弛与节温器异常。待冷却后再开盖检查，需要时请专业维修人员处理。
- 证据：SRC-LANDINI-LANDPOWER-TDI-3681715M1；PDF物理第48页；印刷页脚 43；冷却水温进入红区的检查顺序。[原厂 PDF 第48页](https://truckmanualshub.com/files/c96552feff1a3e458568c1480bd83d80cc489d63a377a55e2d02767ae960a924.pdf#page=48)

## KB-LANDINI-LANDPOWER-TDI-3681715M1-034｜干式空滤红灯时外滤芯清洁与内滤芯更换

- 适用条件：仅 2005 年 Landini 3681 715 M1 所列 Landpower 125／135／145／165／185 TDI，核对铭牌与实车装配。
- 故障现象：干式空滤红灯时外滤芯清洁与内滤芯更换。
- 诊断步骤：停机后按图 5-11 取外滤芯，从内向外用干燥压缩空气清洁，压力上限 4 bar（60 psi）。外滤芯清洗六次、满一年或出现孔裂时更换。原厂要求内安全滤芯每清洁外滤芯三次更换一次，内芯严禁用气吹。
- 证据：SRC-LANDINI-LANDPOWER-TDI-3681715M1；PDF物理第135页；印刷页脚 130；干式空滤红灯时外滤芯清洁与内滤芯更换。[原厂 PDF 第135页](https://truckmanualshub.com/files/c96552feff1a3e458568c1480bd83d80cc489d63a377a55e2d02767ae960a924.pdf#page=135)

## KB-LANDINI-LANDPOWER-TDI-3681715M1-036｜液压泵吸油滤芯更换与检查

- 适用条件：仅 2005 年 Landini 3681 715 M1 所列 Landpower 125／135／145／165／185 TDI，核对铭牌与实车装配。
- 故障现象：液压泵吸油滤芯更换与检查。
- 诊断步骤：确认图 5-20 所示吸油滤芯及实际堵塞警告。新滤芯密封环用清洁新油润滑，密封环接触后手拧半圈，避免过紧。原厂列首次 50 小时，其后 250 小时倍数或堵塞灯亮时更换，作业后检查漏油与油位。
- 证据：SRC-LANDINI-LANDPOWER-TDI-3681715M1；PDF物理第139页；印刷页脚 134；液压泵吸油滤芯更换与检查。[原厂 PDF 第139页](https://truckmanualshub.com/files/c96552feff1a3e458568c1480bd83d80cc489d63a377a55e2d02767ae960a924.pdf#page=139)

